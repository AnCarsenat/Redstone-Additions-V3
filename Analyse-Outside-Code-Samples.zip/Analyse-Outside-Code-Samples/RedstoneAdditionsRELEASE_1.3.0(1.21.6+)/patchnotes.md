# Redstone Additions Datapack - Patch Notes
RELEASES

---
## Version 1.2.0 [THE MR CLEAN UPDATE] (Latest) BETA 1.21.6
Cleaned up source code
Removed out of date libraries
### Added
- 

### Changed
- 

### Fixed
- Block placer not functioning (critical)

### Removed
- Block rotator (unused)
- Exporter (unused)
- Block Placer (temporary)
*block placer removed temporarly because library I was using did not get updated to latest*

---
## Version 1.1.4 [THE KILL THE BUGS UPDATE] (Previous) 1.21.5

### Added
- Blocks now drop
- Recipe pictures

### Changed
- 

### Fixed
- Dispenser dupe (REFIX)
- Generate script clean up
- Adapted to new version (1.21.4=>1.21.5)

### Removed
- 

---
## Version 1.1.3 [THE SURVIFUL UPDATE] 1.21.5

### Added
- Blocks now drop

### Changed
- 

### Fixed
- Dispenser dupe
- Generate script clean up
- Adapted to new version (1.21.4=>1.21.5)
- Block breakers breaking bedrock

### Removed
- 

ALPHA
---
## Version 1.1.2 1.21.4

### Added
- Settings : Enable/Disable certain blocsk (WIP)

### Changed
- 

### Fixed
- Recipes and advancements

### Removed
- 

## Version 1.1.1 ()

### Added
- Breeder: Breeds animals

### Changed
- Blocks now drop

### Fixed
- 

### Removed
- 

## Version 1.0.1 ()

### Added
- Block rotator: Rotates blocks in front of it when powered (WIP)
- Exporter: Links two containers together to transfer items (WIP)

### Changed
- 

### Fixed
- Minor bug fixes

### Removed
- 
BETA
---
## Version 1.0.0 ()

### Added
- Block breaker: Automatically breaks blocks in front of it when powered
- Block placer: Places blocks from its inventory when powered
- Conveyor: Pushes items in the direction it's facing
- Lava reactor: Generates resources using lava
- Mineral reactor: Generates mineral resources
- Organic reactor: Generates organic resources
- Cores (Lava, Water, Air, Earth, Mineral): Essential crafting components for reactors

### Changed
- 

### Fixed
-

### Removed
-

---
*For detailed information about features and changes, please visit our [documentation](link-to-documentation).*


#TEMPLATE  
```markdown
## Version X.X.X ()

### Added
- 

### Changed
- 

### Fixed
-

### Removed
-
```