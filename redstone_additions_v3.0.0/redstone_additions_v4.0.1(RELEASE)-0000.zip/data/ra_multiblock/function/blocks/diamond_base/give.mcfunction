# /ra_multiblock:blocks/diamond_base/give
# Thin wrapper — delegates to macro
function ra_multiblock:blocks/base_give with storage ra:multiblock tier_data.diamond
